text = input("Please enter a text: ")
lenght = len(text)

print("There are following characters in the text: ", lenght)